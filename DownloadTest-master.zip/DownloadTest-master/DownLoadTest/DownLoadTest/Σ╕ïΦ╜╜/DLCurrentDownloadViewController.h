//
//  DLCurrentDownloadViewController.h
//  DownLoadTest
//
//  Created by 李五民 on 15/10/24.
//  Copyright © 2015年 李五民. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString *const DLAddDownloadTaskNotification;
extern NSString *const DLSuspendTaskNotification;
extern NSString *const DLSuspendAndRestartTaskNotification;
extern NSString *const DLAutoStartTaskNotification;

@interface DLCurrentDownloadViewController : UIViewController

@end
