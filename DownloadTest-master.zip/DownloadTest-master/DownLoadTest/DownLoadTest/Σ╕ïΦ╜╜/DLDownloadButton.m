//
//  DLDownloadButton.m
//  DownLoadTest
//
//  Created by 李五民 on 15/11/4.
//  Copyright © 2015年 李五民. All rights reserved.
//

#import "DLDownloadButton.h"

@implementation DLDownloadButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
