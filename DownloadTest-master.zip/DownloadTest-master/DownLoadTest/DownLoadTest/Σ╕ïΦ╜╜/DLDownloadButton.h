//
//  DLDownloadButton.h
//  DownLoadTest
//
//  Created by 李五民 on 15/11/4.
//  Copyright © 2015年 李五民. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLDownloadButton : UIButton

@property (nonatomic ,assign) BOOL isAllSelected;

@end
