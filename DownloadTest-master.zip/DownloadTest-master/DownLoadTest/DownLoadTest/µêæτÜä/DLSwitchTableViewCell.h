//
//  DLSwitchTableViewCell.h
//  DownLoadTest
//
//  Created by 李五民 on 15/10/26.
//  Copyright © 2015年 李五民. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLSwitchTableViewCell : UITableViewCell

@end
