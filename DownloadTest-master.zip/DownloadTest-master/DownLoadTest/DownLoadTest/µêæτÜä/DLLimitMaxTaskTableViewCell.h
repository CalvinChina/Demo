//
//  DLLimitMaxTaskTableViewCell.h
//  DownLoadTest
//
//  Created by 李五民 on 15/10/26.
//  Copyright © 2015年 李五民. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DLMaxLinkTextFieldView.h"
@interface DLLimitMaxTaskTableViewCell : UITableViewCell

@property (nonatomic,strong) DLMaxLinkTextFieldView *limitTextField;

@end
